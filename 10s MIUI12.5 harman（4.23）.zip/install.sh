SKIPMOUNT=false
#安装后开关
PROPFILE=true
#system.prop文件
POSTFSDATA=false
#post-fs-data脚本
LATESTARTSERVICE=false
#service.sh中脚本
print_modname() {
  ui_print "*******************************"
  ui_print "12.0.2.8音质音效移植MIUI12.5"
  ui_print "酷安搜搜:恬柒"
}
on_install() {
ui_print "- 1s后开始生成本设备音效固件反馈文件"
sleep 1s
/system/vendor/etc/dolby/dax-default.xml
/system/etc/mixer_paths.xml
/system/etc/mixer_paths_cdp.xml
/system/vendor/etc/audio/sku_taro/audio_effects.conf
/system/vendor/etc/audio/sku_taro/audio_effects.xml
/system/vendor/etc/audio/sku_taro/audio_policy_configuration.xml
/system/vendor/etc/audio/sku_taro/mixer_paths_overlay_dynamic.xml
/system/vendor/etc/audio/sku_taro/mixer_paths_overlay_static.xml
/system/vendor/etc/audio/sku_taro/mixer_paths_waipio_cdp.xml
/system/vendor/etc/audio/sku_taro/mixer_paths_waipio_mtp.xml
/system/vendor/etc/audio/sku_taro/mixer_paths_waipio_qrd.xml
/system/vendor/etc/audio/sku_taro/resourcemanager_upd.xml
/system/vendor/etc/audio/sku_taro/resourcemanager_waipio_cdp.xml
/system/vendor/etc/audio/sku_taro/resourcemanager_waipio_mtp.xml
/system/vendor/etc/audio/sku_taro/resourcemanager_waipio_qrd.xml
/system/vendor/lib/rfsa/adsp/misound_karaoke_res.bin
/system/vendor/lib/rfsa/adsp/misound_karaokemix_res.bin
/system/vendor/lib/rfsa/adsp/misound_res.bin
/system/vendor/lib/rfsa/adsp/misound_res_headphone.bin
/system/vendor/lib/rfsa/adsp/misound_res_spk.bin
sleep 1s
if [ -d /storage/emulated/0/.音效固件打包专用  ];then
        echo 检测到残留
          rm -rf /storage/emulated/0/.音效固件打包专用
else
        echo 开始生成
fi
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/firmware
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib64
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/etc
mkdir -p /storage/emulated/0/.音效固件打包专用/system/app
mkdir -p /storage/emulated/0/.音效固件打包专用/system/vendor/lib
sleep 1s
cp -r /system/vendor/lib/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib/
cp -r /system/vendor/etc/audio /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/app/MiSound /storage/emulated/0/.音效固件打包专用/system/app/
cp -r /system/vendor/etc/acdbdata /storage/emulated/0/.音效固件打包专用/system/vendor/etc/
cp -r /system/vendor/lib64/soundfx /storage/emulated/0/.音效固件打包专用/system/vendor/lib64/
cp -r /system/vendor/firmware/aw8697_rtp_1.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/
cp -r /system/vendor/firmware/aw8697_haptic.bin /storage/emulated/0/.音效固件打包专用/system/vendor/firmware/
sleep 2s
tar -cvzf 音效固件打包.tar.gz /storage/emulated/0/.音效固件打包专用/ 
cp -r ./音效固件打包.tar.gz /storage/emulated/0/
rm -rf ./音效固件打包.tar.gz
rm -rf /storage/emulated/0/.音效固件打包专用
sleep 1s
rename /storage/emulated/0/音效固件打包.tar.gz /storage/emulated/0/音效固件打包.zip
  ui_print "- 生成完毕，保存在根目录，正在安装"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- 安装完毕，开始清理碎片"
    /dev/*/.magisk/busybox/fstrim -v /cache 
    rm -rf /data/system/package_cache/*
  ui_print "重启请重新校准扬声器再重启，不好用再重刷一遍"
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}